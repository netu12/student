/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.studentrecord;

/**
 *
 * @author Sharad Pratap Singh
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class StudentManagementSystem extends JFrame {
    private JTable table;
    private final DefaultTableModel tableModel;
    private final ArrayList<Student> students = new ArrayList<>();

    private JTextField nameField, ageField, fatherNameField, motherNameField, addressField, mobileField, courseField;

    public StudentManagementSystem() {
        setTitle("Student Management System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // UI Components
        JPanel formPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Add Student"));
        nameField = new JTextField();
        ageField = new JTextField();
        fatherNameField = new JTextField();
        motherNameField = new JTextField();
        addressField = new JTextField();
        mobileField = new JTextField();
        courseField = new JTextField();

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Age:"));
        formPanel.add(ageField);
        formPanel.add(new JLabel("Father's Name:"));
        formPanel.add(fatherNameField);
        formPanel.add(new JLabel("Mother's Name:"));
        formPanel.add(motherNameField);
        formPanel.add(new JLabel("Address:"));
        formPanel.add(addressField);
        formPanel.add(new JLabel("Mobile:"));
        formPanel.add(mobileField);
        formPanel.add(new JLabel("Course:"));
        formPanel.add(courseField);

        JButton addButton = new JButton("Add Student");
        formPanel.add(addButton);

        addButton.addActionListener(e -> addStudent());

        // Table Setup
        String[] columns = {"Name", "Age", "Father's Name", "Mother's Name", "Address", "Mobile", "Course", "Actions"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        JScrollPane tablePane = new JScrollPane(table);

        // Buttons for Edit/Delete
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent evt) {
                int row = table.getSelectedRow();
                int col = table.getSelectedColumn();
                if (col == 7) {
                    String[] options = {"Edit", "Delete"};
                    int choice = JOptionPane.showOptionDialog(null, "Choose Action", "Edit/Delete",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
                    if (choice == 0) {
                        editStudent(row);
                    } else if (choice == 1) {
                        deleteStudent(row);
                    }
                }
            }
        });

        setLayout(new BorderLayout());
        add(formPanel, BorderLayout.NORTH);
        add(tablePane, BorderLayout.CENTER);
    }

    private void addStudent() {
        String name = nameField.getText();
        String age = ageField.getText();
        String father = fatherNameField.getText();
        String mother = motherNameField.getText();
        String address = addressField.getText();
        String mobile = mobileField.getText();
        String course = courseField.getText();

        if (name.isEmpty() || age.isEmpty() || mobile.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all required fields.");
            return;
        }

        Student student = new Student(name, age, father, mother, address, mobile, course);
        students.add(student);
        tableModel.addRow(new Object[]{name, age, father, mother, address, mobile, course, "Edit/Delete"});

        // Reset form
        nameField.setText("");
        ageField.setText("");
        fatherNameField.setText("");
        motherNameField.setText("");
        addressField.setText("");
        mobileField.setText("");
        courseField.setText("");
    }

    private void deleteStudent(int index) {
        students.remove(index);
        tableModel.removeRow(index);
    }

    private void editStudent(int index) {
        Student s = students.get(index);
        nameField.setText(s.name);
        ageField.setText(s.age);
        fatherNameField.setText(s.fatherName);
        motherNameField.setText(s.motherName);
        addressField.setText(s.address);
        mobileField.setText(s.mobile);
        courseField.setText(s.course);

        JButton updateButton = new JButton("Update Student");
        JPanel panel = new JPanel();
        panel.add(updateButton);
        add(panel, BorderLayout.SOUTH);
        revalidate();

        updateButton.addActionListener(e -> {
            s.name = nameField.getText();
            s.age = ageField.getText();
            s.fatherName = fatherNameField.getText();
            s.motherName = motherNameField.getText();
            s.address = addressField.getText();
            s.mobile = mobileField.getText();
            s.course = courseField.getText();

            tableModel.setValueAt(s.name, index, 0);
            tableModel.setValueAt(s.age, index, 1);
            tableModel.setValueAt(s.fatherName, index, 2);
            tableModel.setValueAt(s.motherName, index, 3);
            tableModel.setValueAt(s.address, index, 4);
            tableModel.setValueAt(s.mobile, index, 5);
            tableModel.setValueAt(s.course, index, 6);

            // Clear form
            nameField.setText("");
            ageField.setText("");
            fatherNameField.setText("");
            motherNameField.setText("");
            addressField.setText("");
            mobileField.setText("");
            courseField.setText("");
            panel.setVisible(false);
        });
    }

    // Student Data Class
    static class Student {
        String name, age, fatherName, motherName, address, mobile, course;

        Student(String name, String age, String father, String mother, String address, String mobile, String course) {
            this.name = name;
            this.age = age;
            this.fatherName = father;
            this.motherName = mother;
            this.address = address;
            this.mobile = mobile;
            this.course = course;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentManagementSystem().setVisible(true));
    }
}
