/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.studentrecord;

/**
 *
 * @author Sharad Pratap Singh
 */
public class student {
    private int id;
    private String name;
    private long mobile;
    private String address;
    private int age;
    private String fatherName;
    private String motherName;
    private String course;

    public student(int id, String name, long mobile, String address, int age, String fatherName, String motherName, String course) {
        this.id = id;
        this.name = name;
        this.mobile = mobile;
        this.address = address;
        this.age = age;
        this.fatherName = fatherName;
        this.motherName = motherName;
        this.course = course;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public long getMobile() {
        return mobile;
    }

    public String getAddress() {
        return address;
    }

    public int getAge() {
        return age;
    }

    public String getFatherName() {
        return fatherName;
    }

    public String getMotherName() {
        return motherName;
    }

    public String getCourse() {
        return course;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMobile(long mobile) {
        this.mobile = mobile;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setFatherName(String fatherName) {
        this.fatherName = fatherName;
    }

    public void setMotherName(String motherName) {
        this.motherName = motherName;
    }

    public void setCourse(String course) {
        this.course = course;
    }
    
    
}
