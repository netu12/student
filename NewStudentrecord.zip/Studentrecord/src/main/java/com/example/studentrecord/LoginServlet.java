package com.example.studentrecord;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        UserDAO dao = new UserDAO();

        if (dao.validateUser(username, password)) {
            // You can store session if needed: request.getSession().setAttribute("user", username);
            response.sendRedirect("home.jsp"); // Redirect to home/dashboard
        } else {
            response.sendRedirect("login.html?error=Invalid+credentials");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Optional: redirect to login page or show a message
        response.sendRedirect("login.html");
    }

    @Override
    public String getServletInfo() {
        return "Login Servlet handles user authentication";
    }
}
